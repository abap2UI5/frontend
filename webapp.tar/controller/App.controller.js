sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("z2ui5odata.controller.App", {
        onInit() {
        }
      });
    }
  );
  