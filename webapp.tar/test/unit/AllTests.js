sap.ui.define([
	"z2ui5_odata/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
