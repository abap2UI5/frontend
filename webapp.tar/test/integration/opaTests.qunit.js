/* global QUnit */

sap.ui.require(["z2ui5odata/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
